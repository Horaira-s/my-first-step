"""
railway_final_with_categories.py

Full system with category-wise seat classes/types and prices for Dhaka->Rajshahi.

- Seat classes & prices:
  - AC Chair    : SNIGDHA, AC_B, AC_S    -> 900 BDT
  - First Class : F_CHAIR, F_SEAT, F_BERTH -> 550 BDT
  - 2nd Class   : SHOVAN, S_CHAIR         -> 400 BDT

- Coach mapping (default):
  A -> AC Chair
  B -> First Class
  C -> First Class
  D -> 2nd Class

Other rules preserved:
- 100 seats/train (4 coaches x 25)
- 35% seats available online (35 seats), distributed fairly
- Booking window: 08:00 - 23:00 Asia/Dhaka
- Max 4 tickets per booking
- Online booking uses only online-flagged seats
"""

from dataclasses import dataclass, field
from datetime import datetime, time
from zoneinfo import ZoneInfo
import itertools
from math import floor
from typing import List, Dict, Optional, Tuple
import re
import sys

# ---------------- CONFIG ----------------
LOCAL_TZ = ZoneInfo("Asia/Dhaka")
ACTIVE_START = time(8, 0)
ACTIVE_END = time(23, 0)
PNR_PREFIX = "PNR"
ONLINE_QUOTA_PERCENT = 0.35
MAX_TICKETS_PER_BOOKING = 4

# New class/type/price definitions (Dhaka -> Rajshahi)
CLASS_TYPES = {
    "AC Chair": ["SNIGDHA", "AC_B", "AC_S"],
    "First Class": ["F_CHAIR", "F_SEAT", "F_BERTH"],
    "2nd Class": ["SHOVAN", "S_CHAIR"],
}

CLASS_PRICE = {
    "AC Chair": 900.0,
    "First Class": 550.0,
    "2nd Class": 400.0,
}

# Default coach -> class mapping for each train
# A: AC Chair, B: First Class, C: First Class, D: 2nd Class
DEFAULT_COACH_CLASSES = {
    "A": "AC Chair",
    "B": "First Class",
    "C": "First Class",
    "D": "2nd Class",
}

# ---------------- Models ----------------

@dataclass
class Seat:
    seat_no: str
    seat_type: Optional[str] = None      # e.g. SNIGDHA, F_CHAIR, SHOVAN
    is_booked: bool = False
    passenger_name: Optional[str] = None
    passenger_age: Optional[int] = None
    pnr: Optional[str] = None
    online_available: bool = False

@dataclass
class Coach:
    coach_id: str
    seat_class: str            # e.g. "AC Chair", "First Class", "2nd Class"
    seats: Dict[str, Seat] = field(default_factory=dict)

    def available_seats(self, only_online: bool = False) -> List[Seat]:
        s = [seat for seat in self.seats.values() if not seat.is_booked]
        if only_online:
            s = [seat for seat in s if seat.online_available]
        s.sort(key=lambda x: x.seat_no)
        return s

    def total_online_available(self) -> int:
        return sum(1 for seat in self.seats.values() if seat.online_available and not seat.is_booked)

@dataclass
class Train:
    train_id: str
    name: str
    departure_time: time
    origin: str
    destination: str
    coaches: Dict[str, Coach] = field(default_factory=dict)

    def total_available_online(self) -> int:
        return sum(coach.total_online_available() for coach in self.coaches.values())

    def total_online_quota(self) -> int:
        return sum(1 for coach in self.coaches.values() for seat in coach.seats.values() if seat.online_available)

    def total_available(self) -> int:
        return sum(len(coach.available_seats()) for coach in self.coaches.values())

@dataclass
class Ticket:
    pnr: str
    train_id: str
    coach_id: str
    seat_no: str
    seat_type: str
    seat_class: str
    passenger_name: str
    passenger_age: int
    fare: float
    booking_time: datetime

# ---------------- Booking System ----------------

class BookingSystem:
    def __init__(self, online_quota_pct: float = ONLINE_QUOTA_PERCENT):
        self.trains: Dict[str, Train] = {}
        self._pnr_counter = itertools.count(1)
        self.online_quota_pct = online_quota_pct

    def is_active_time(self, check_dt: Optional[datetime] = None) -> bool:
        now = check_dt or datetime.now(LOCAL_TZ)
        t = now.time()
        return (t >= ACTIVE_START) and (t < ACTIVE_END)

    def _generate_pnr(self) -> str:
        n = next(self._pnr_counter)
        date_part = datetime.now(LOCAL_TZ).strftime("%Y%m%d")
        return f"{PNR_PREFIX}-{date_part}-{n:04d}"

    def create_train(self, train_id: str, name: str, departure_time: time,
                     origin: str, destination: str, coach_configs: List[dict]):
        """
        coach_configs: list of {"coach_id": "A", "seat_count": 25, "seat_class": "AC Chair" (optional)}
        If seat_class omitted, default mapping DEFAULT_COACH_CLASSES is used.
        Seats are assigned seat_type in round-robin from CLASS_TYPES[seat_class].
        """
        if train_id in self.trains:
            raise ValueError(f"Train {train_id} already exists")

        train = Train(train_id=train_id, name=name, departure_time=departure_time,
                      origin=origin, destination=destination)

        for cfg in coach_configs:
            coach_id = cfg["coach_id"]
            seat_count = cfg.get("seat_count", 25)
            # decide class for this coach: cfg overrides defaults
            seat_class = cfg.get("seat_class") or DEFAULT_COACH_CLASSES.get(coach_id, "2nd Class")
            coach = Coach(coach_id=coach_id, seat_class=seat_class)
            types = CLASS_TYPES.get(seat_class, ["GEN"])
            # assign types in round-robin
            for i in range(1, seat_count + 1):
                seat_no = f"{coach_id}-{i:02d}"
                seat_type = types[(i-1) % len(types)]
                coach.seats[seat_no] = Seat(seat_no=seat_no, seat_type=seat_type)
            train.coaches[coach.coach_id] = coach

        # compute online quota
        total_seats = sum(cfg.get("seat_count",25) for cfg in coach_configs)
        online_quota = int(round(total_seats * self.online_quota_pct))

        # distribute online_quota fairly across coaches
        coach_counts = [cfg.get("seat_count",25) for cfg in coach_configs]
        bases = [floor(c * self.online_quota_pct) for c in coach_counts]
        assigned = sum(bases)
        remainder = online_quota - assigned
        fractions = [(i, (coach_counts[i] * self.online_quota_pct) - bases[i]) for i in range(len(coach_counts))]
        fractions.sort(key=lambda x: (-x[1], x[0]))
        extras = [0]*len(coach_counts)
        for i in range(remainder):
            extras[fractions[i][0]] += 1
        for idx, cfg in enumerate(coach_configs):
            cid = cfg["coach_id"]
            count_online = bases[idx] + extras[idx]
            coach = train.coaches[cid]
            seat_keys_sorted = sorted(coach.seats.keys())
            for s_no in seat_keys_sorted[:count_online]:
                coach.seats[s_no].online_available = True

        self.trains[train_id] = train

    # Auto-assign booking (uses seat_class -> price mapping)
    def book_tickets_auto(self, train_id: str, passengers: List[dict], preferred_class: Optional[str] = None) -> Tuple[bool, str, List[Ticket]]:
        if not self.is_active_time():
            return False, f"Booking denied: Booking allowed only between {ACTIVE_START.strftime('%H:%M')} and {ACTIVE_END.strftime('%H:%M')} (Asia/Dhaka).", []
        if not passengers or len(passengers)==0:
            return False, "No passengers provided.", []
        if len(passengers) > MAX_TICKETS_PER_BOOKING:
            return False, f"Booking denied: max {MAX_TICKETS_PER_BOOKING} tickets per booking.", []
        if train_id not in self.trains:
            return False, "Train not found.", []
        train = self.trains[train_id]
        need = len(passengers)
        avail_online = train.total_available_online()
        if need > avail_online:
            if avail_online == 0:
                return False, f"No online seats available for train {train_id}.", []
            else:
                return False, f"Only {avail_online} online seat(s) available for train {train_id}, you requested {need}.", []

        # allocation pool (only online seats)
        allocation_slots = []
        if preferred_class:
            for coach in train.coaches.values():
                if coach.seat_class == preferred_class:
                    allocation_slots.extend([(coach, s) for s in coach.available_seats(only_online=True)])
        if len(allocation_slots) < need:
            for coach in train.coaches.values():
                if preferred_class and coach.seat_class == preferred_class:
                    continue
                allocation_slots.extend([(coach, s) for s in coach.available_seats(only_online=True)])
        if len(allocation_slots) < need:
            return False, "Unexpected allocation error.", []

        tickets = []
        booking_time = datetime.now(LOCAL_TZ)
        for i, p in enumerate(passengers):
            coach, seat = allocation_slots[i]
            pnr = self._generate_pnr()
            seat.is_booked = True
            seat.passenger_name = p["name"]
            seat.passenger_age = p["age"]
            seat.pnr = pnr
            fare = CLASS_PRICE.get(coach.seat_class, 0.0)
            ticket = Ticket(pnr=pnr, train_id=train_id, coach_id=coach.coach_id, seat_no=seat.seat_no,
                            seat_type=seat.seat_type, seat_class=coach.seat_class,
                            passenger_name=p["name"], passenger_age=p["age"],
                            fare=fare, booking_time=booking_time)
            tickets.append(ticket)
        return True, f"Booking successful: {len(tickets)} ticket(s) issued.", tickets

    # Book specific seats (must be online_available)
    def book_specific_seats(self, train_id: str, seat_nos: List[str], passengers: List[dict]) -> Tuple[bool,str,List[Ticket]]:
        if not self.is_active_time():
            return False, f"Booking denied: Booking allowed only between {ACTIVE_START.strftime('%H:%M')} and {ACTIVE_END.strftime('%H:%M')} (Asia/Dhaka).", []
        if len(seat_nos)==0 or len(seat_nos)!=len(passengers):
            return False, "Seat count and passenger count mismatch.", []
        if len(seat_nos) > MAX_TICKETS_PER_BOOKING:
            return False, f"Booking denied: max {MAX_TICKETS_PER_BOOKING} tickets per booking.", []
        if train_id not in self.trains:
            return False, "Train not found.", []
        train = self.trains[train_id]
        tickets=[]
        booking_time = datetime.now(LOCAL_TZ)
        for idx, s_no in enumerate(seat_nos):
            found=False
            for coach in train.coaches.values():
                if s_no in coach.seats:
                    found=True
                    seat = coach.seats[s_no]
                    if not seat.online_available:
                        return False, f"Seat {s_no} not available for online booking.", []
                    if seat.is_booked:
                        return False, f"Seat {s_no} already booked.", []
                    p = passengers[idx]
                    pnr = self._generate_pnr()
                    seat.is_booked=True
                    seat.passenger_name=p["name"]
                    seat.passenger_age=p["age"]
                    seat.pnr=pnr
                    fare = CLASS_PRICE.get(coach.seat_class, 0.0)
                    ticket = Ticket(pnr=pnr, train_id=train_id, coach_id=coach.coach_id, seat_no=seat.seat_no,
                                    seat_type=seat.seat_type, seat_class=coach.seat_class,
                                    passenger_name=p["name"], passenger_age=p["age"],
                                    fare=fare, booking_time=booking_time)
                    tickets.append(ticket)
                    break
            if not found:
                return False, f"Seat {s_no} not found on train {train_id}.", []
        return True, f"Booking successful: {len(tickets)} ticket(s) issued.", tickets

    def cancel_ticket(self, train_id: str, pnr: str) -> bool:
        if train_id not in self.trains:
            return False
        train = self.trains[train_id]
        for coach in train.coaches.values():
            for seat in coach.seats.values():
                if seat.pnr == pnr:
                    seat.is_booked=False
                    seat.passenger_name=None
                    seat.passenger_age=None
                    seat.pnr=None
                    return True
        return False

    # Helpers for UI
    def print_train_status(self, train_id: str):
        if train_id not in self.trains:
            print("Train not found.")
            return
        train = self.trains[train_id]
        print(f"\nTrain: {train.name} ({train.train_id}) | {train.origin}→{train.destination} | Departs: {train.departure_time.strftime('%H:%M')}")
        print(f"Online quota seats total: {train.total_online_quota()}")
        for coach in sorted(train.coaches.values(), key=lambda c:c.coach_id):
            total=len(coach.seats)
            booked=sum(1 for s in coach.seats.values() if s.is_booked)
            online_quota=sum(1 for s in coach.seats.values() if s.online_available)
            online_booked=sum(1 for s in coach.seats.values() if s.online_available and s.is_booked)
            price = CLASS_PRICE.get(coach.seat_class, 0.0)
            print(f"  Coach {coach.coach_id} ({coach.seat_class}) - Fare: BDT {price:.0f} : online {online_booked}/{online_quota} | total {booked}/{total}")
        print(f"Total online seats available (not booked): {train.total_available_online()}")
        print(f"Total seats available (not booked): {train.total_available()}")

    def list_online_seats(self, train_id: str, coach_id: str) -> List[str]:
        if train_id not in self.trains:
            return []
        train = self.trains[train_id]
        if coach_id not in train.coaches:
            return []
        coach = train.coaches[coach_id]
        return [s.seat_no + f"({s.seat_type})" for s in coach.available_seats(only_online=True)]

    def _print_confirmation_box(self, train_name: str, tickets: List[Ticket], phone_no: str):
        # group and display as before but include class and types summary
        coach_map: Dict[str, List[str]] = {}
        for t in tickets:
            coach = t.coach_id
            num = str(int(t.seat_no.split("-")[1]))
            coach_map.setdefault(coach, []).append(num)
        content_lines = ["Congratulation! Your ticket/s are booked successfully.", f"Train: {train_name}"]
        if len(coach_map)==1:
            c = next(iter(coach_map))
            nums = ",".join(sorted(coach_map[c], key=lambda x:int(x)))
            content_lines.append(f"Coach: {c}")
            content_lines.append(f"Seat Range: {nums}")
        else:
            for c in sorted(coach_map.keys()):
                nums = ",".join(sorted(coach_map[c], key=lambda x:int(x)))
                content_lines.append(f"{c}: Seats {nums}")
        content_lines.append(f"Phone No.: {phone_no}")
        width = max(len(line) for line in content_lines)+4
        hr = "+" + "-"*(width-2) + "+"
        print("\n" + hr)
        for i,line in enumerate(content_lines):
            padding = width-2-len(line)
            print("| " + line + " "*padding + "|")
            if i==0:
                print("|" + "-"*(width-2) + "|")
        print(hr + "\n")

# ---------------- Setup trains ----------------

COACHES_100 = [
    {"coach_id":"A","seat_count":25, "seat_class": DEFAULT_COACH_CLASSES["A"]},
    {"coach_id":"B","seat_count":25, "seat_class": DEFAULT_COACH_CLASSES["B"]},
    {"coach_id":"C","seat_count":25, "seat_class": DEFAULT_COACH_CLASSES["C"]},
    {"coach_id":"D","seat_count":25, "seat_class": DEFAULT_COACH_CLASSES["D"]},
]

DAILY_TRAINS = [
    {"train_id":"BAN001","name":"BANALATA","departure_time":time(8,30),"origin":"Dhaka","destination":"Rajshahi","coaches":COACHES_100},
    {"train_id":"PAD001","name":"PADMA","departure_time":time(16,30),"origin":"Dhaka","destination":"Rajshahi","coaches":COACHES_100},
]

# ---------------- CLI helpers (condensed) ----------------

def input_positive_int(prompt:str, min_v:int=1, max_v:Optional[int]=None) -> int:
    while True:
        s = input(prompt).strip()
        if not s.isdigit():
            print("Please enter a valid number.")
            continue
        n = int(s)
        if n < min_v:
            print(f"Value must be at least {min_v}.")
            continue
        if max_v and n > max_v:
            print(f"Value must be at most {max_v}.")
            continue
        return n

def input_phone(prompt:str="Enter phone (e.g. 01700000000 or 01700-000000): ")->str:
    while True:
        ph = input(prompt).strip()
        if re.fullmatch(r"[0-9\-]{7,15}", ph):
            return ph
        print("Invalid phone format. Only digits and optional dash allowed.")

def input_passengers(count:int) -> List[dict]:
    passengers=[]
    for i in range(count):
        name = input(f"Passenger {i+1} name: ").strip() or f"Passenger{i+1}"
        age = input_positive_int(f"Passenger {i+1} age: ", min_v=0, max_v=120)
        passengers.append({"name":name,"age":age})
    return passengers

def print_main_menu():
    print("\n--- Railway Online Booking ---")
    print("1) List trains")
    print("2) Show train availability")
    print("3) Buy tickets (auto assign)")
    print("4) Buy tickets (choose seats)")
    print("5) Cancel ticket (by PNR)")
    print("6) Exit")

def run_cli():
    system = BookingSystem()
    # create trains
    for cfg in DAILY_TRAINS:
        system.create_train(train_id=cfg["train_id"], name=cfg["name"],
                            departure_time=cfg["departure_time"],
                            origin=cfg["origin"], destination=cfg["destination"],
                            coach_configs=cfg["coaches"])
    print("System initialized. (Active booking window: 08:00 - 23:00 Asia/Dhaka)\n")

    while True:
        print_main_menu()
        choice = input("Select option: ").strip()
        if choice=="1":
            print("\nAvailable trains:")
            for t in DAILY_TRAINS:
                print(f"  {t['train_id']}: {t['name']} | {t['origin']}→{t['destination']} | Departs {t['departure_time'].strftime('%H:%M')}")
        elif choice=="2":
            tid = input("Enter train id (e.g. BAN001): ").strip()
            system.print_train_status(tid)
            for c in ["A","B","C","D"]:
                seats = system.list_online_seats(tid,c)
                print(f"  {c}: {len(seats)} -> {', '.join(seats) if seats else 'None'}")
        elif choice=="3":
            tid = input("Enter train id (e.g. BAN001): ").strip()
            num = input_positive_int(f"How many tickets? (1-{MAX_TICKETS_PER_BOOKING}): ", min_v=1, max_v=MAX_TICKETS_PER_BOOKING)
            passengers = input_passengers(num)
            phone = input_phone()
            pref = input("Preferred class? (AC Chair/First Class/2nd Class or press Enter): ").strip()
            pref = pref if pref in CLASS_TYPES else None
            ok,msg,tickets = system.book_tickets_auto(tid, passengers, preferred_class=pref)
            if not ok:
                print("ERROR:",msg)
            else:
                system._print_confirmation_box(system.trains[tid].name, tickets, phone)
                print("Tickets:")
                for t in tickets:
                    print(f" PNR: {t.pnr} | Coach {t.coach_id} | Seat {t.seat_no} ({t.seat_type}) | {t.seat_class} | Fare: BDT {t.fare:.2f} | {t.passenger_name} ({t.passenger_age})")
        elif choice=="4":
            tid = input("Enter train id (e.g. BAN001): ").strip()
            num = input_positive_int(f"How many tickets? (1-{MAX_TICKETS_PER_BOOKING}): ", min_v=1, max_v=MAX_TICKETS_PER_BOOKING)
            print("Available online seats by coach (with types):")
            for c in ["A","B","C","D"]:
                seats = system.list_online_seats(tid,c)
                print(f"  {c}: {len(seats)} -> {', '.join(seats) if seats else 'None'}")
            seat_input = input("Enter desired seat numbers separated by commas (e.g. A-01,A-02): ").strip()
            seat_nos = [s.strip().upper() for s in seat_input.split(",") if s.strip()]
            if len(seat_nos)!=num:
                print("Number of seats entered doesn't match passenger count. Try again.")
                continue
            passengers = input_passengers(num)
            phone = input_phone()
            ok,msg,tickets = system.book_specific_seats(tid, seat_nos, passengers)
            if not ok:
                print("ERROR:",msg)
            else:
                system._print_confirmation_box(system.trains[tid].name, tickets, phone)
                print("Tickets:")
                for t in tickets:
                    print(f" PNR: {t.pnr} | Coach {t.coach_id} | Seat {t.seat_no} ({t.seat_type}) | {t.seat_class} | Fare: BDT {t.fare:.2f} | {t.passenger_name} ({t.passenger_age})")
        elif choice=="5":
            tid = input("Enter train id (e.g. BAN001): ").strip()
            pnr = input("Enter PNR to cancel: ").strip()
            ok = system.cancel_ticket(tid, pnr)
            print("Cancellation successful." if ok else "Cancellation failed (PNR not found).")
        elif choice=="6":
            print("Exiting. Goodbye.")
            sys.exit(0)
        else:
            print("Unknown option. Please try again.")

if __name__ == "__main__":
    run_cli()

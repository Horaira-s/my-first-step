import {
  Brain,
  Database,
  Server,
  Network,
  Cloud,
  GitBranch,
  Code2,
} from "lucide-react";
import { motion } from "motion/react";
import { useInView } from "./hooks/useInView";

const skillCategories = [
  {
    icon: Brain,
    title: "AI App Development",
    skills: [
      "TensorFlow",
      "PyTorch",
      "AI Model Integration",
      "Neural Networks",
      "AI API Development",
    ],
  },
  {
    icon: Database,
    title: "Programming Languages",
    skills: ["Python", "C", "C++", "JavaScript", "SQL"],
  },
  {
    icon: Server,
    title: "Big Data and IOT based Project Experience",
    skills: [
      "IoT Architecture",
      "Sensor Integration",
      "Big Data Analytics",
      "Data Pipeline",
      "Cisco Network",
    ],
  },
  {
    icon: Network,
    title: "Machine Learning Project",
    skills: [
      "Deep Learning",
      "NLP",
      "Scikit-learn",
      "Data Science",
      "Model Training",
    ],
  },
  {
    icon: Code2,
    title: "Python Backend Developer",
    skills: [
      "Django",
      "Flask",
      "FastAPI",
      "REST APIs",
      "PostgreSQL",
    ],
  },
  {
    icon: Cloud,
    title: "Web Development",
    skills: [
      "HTML",
      "CSS",
      "JavaScript",
      "React",
      "Responsive Design",
    ],
  },
  {
    icon: GitBranch,
    title: "Tools & Others",
    skills: [
      "Git",
      "GitHub",
      "VS Code",
      "Jupyter Notebook",
      "Data Analysis",
    ],
  },
];

export function Skills() {
  const { ref, isInView } = useInView();

  return (
    <section id="skills" className="py-20 bg-[#0a0a0f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={
            isInView
              ? { opacity: 1, y: 0 }
              : { opacity: 0, y: 50 }
          }
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl text-center text-white mb-4">
            Skills & Expertise
          </h2>
          <p className="text-lg text-center text-gray-400 mb-12 max-w-2xl mx-auto">
            A comprehensive toolkit of technologies and skills I
            use to bring ideas to life
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 20 }}
                animate={
                  isInView
                    ? { opacity: 1, y: 0 }
                    : { opacity: 0, y: 20 }
                }
                transition={{
                  duration: 0.5,
                  delay: index * 0.1,
                }}
                className="bg-[#18181b] p-6 rounded-lg border border-white/10 hover:border-blue-500/50 transition-all hover:shadow-xl hover:shadow-blue-500/10"
              >
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-blue-500/10 rounded-lg mr-4 border border-blue-500/20">
                    <category.icon
                      className="text-blue-500"
                      size={24}
                    />
                  </div>
                  <h3 className="text-xl text-white">
                    {category.title}
                  </h3>
                </div>
                <ul className="space-y-2">
                  {category.skills.map((skill) => (
                    <li
                      key={skill}
                      className="text-gray-300 flex items-center"
                    >
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                      {skill}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
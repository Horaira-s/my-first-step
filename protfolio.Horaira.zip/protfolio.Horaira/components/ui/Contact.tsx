import { Mail, Phone, MapPin, Send, Facebook, Instagram } from 'lucide-react';
import { motion } from 'motion/react';
import { useInView } from './hooks/useInView';
import { useState } from 'react';

export function Contact() {
  const { ref, isInView } = useInView();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to a backend
    console.log('Form submitted:', formData);
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-20 bg-[#0a0a0f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl text-center text-white mb-4">Get In Touch</h2>
          <p className="text-lg text-center text-gray-400 mb-12 max-w-2xl mx-auto">
            Have a project in mind or just want to say hi? Feel free to reach out!
          </p>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl text-white mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="p-3 bg-blue-500/10 rounded-lg mr-4 border border-blue-500/20">
                    <Mail className="text-blue-500" size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg text-white mb-1">Email</h4>
                    <a href="mailto:sarder2205101514@diu.edu" className="text-gray-400 hover:text-blue-500 transition-colors">
                      sarder2205101514@diu.edu
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="p-3 bg-blue-500/10 rounded-lg mr-4 border border-blue-500/20">
                    <Phone className="text-blue-500" size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg text-white mb-1">Phone</h4>
                    <a href="tel:+8801812324943" className="text-gray-400 hover:text-blue-500 transition-colors">
                      +880 1812-324943
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="p-3 bg-blue-500/10 rounded-lg mr-4 border border-blue-500/20">
                    <MapPin className="text-blue-500" size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg text-white mb-1">Location</h4>
                    <p className="text-gray-400">Dhaka, Bangladesh</p>
                  </div>
                </div>
              </div>

              {/* Social Media Links */}
              <div className="mt-8 pt-8 border-t border-white/10">
                <h4 className="text-lg text-white mb-4">Connect With Me</h4>
                <div className="flex space-x-4">
                  <a
                    href="https://www.facebook.com/horaira2219"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center justify-center w-12 h-12 bg-gradient-to-br from-blue-600/20 to-blue-500/10 border border-blue-500/30 rounded-lg hover:from-blue-600/30 hover:to-blue-500/20 hover:border-blue-500/50 transition-all duration-300"
                    aria-label="Facebook Profile"
                  >
                    <Facebook className="text-blue-400 group-hover:text-blue-300 transition-colors" size={24} />
                  </a>
                  <a
                    href="https://www.instagram.com/horaira2219/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center justify-center w-12 h-12 bg-gradient-to-br from-pink-600/20 to-purple-500/10 border border-pink-500/30 rounded-lg hover:from-pink-600/30 hover:to-purple-500/20 hover:border-pink-500/50 transition-all duration-300"
                    aria-label="Instagram Profile"
                  >
                    <Instagram className="text-pink-400 group-hover:text-pink-300 transition-colors" size={24} />
                  </a>
                </div>
              </div>
            </div>

            <div>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-gray-300 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-[#18181b] border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder:text-gray-500"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-[#18181b] border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder:text-gray-500"
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-gray-300 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 bg-[#18181b] border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none text-white placeholder:text-gray-500"
                    placeholder="Your message..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitted}
                  className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center disabled:bg-green-600"
                >
                  {isSubmitted ? (
                    <>Message Sent!</>
                  ) : (
                    <>
                      <Send size={18} className="mr-2" />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="mt-20 pt-8 border-t border-white/10">
        <p className="text-center text-gray-400">
          © {new Date().getFullYear()} Horaira. All rights reserved.
        </p>
      </div>
    </section>
  );
}

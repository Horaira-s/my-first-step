import { Github, Linkedin, Mail, ArrowDown, Sun, CloudSun, Sunset, Moon } from 'lucide-react';
import { motion } from 'motion/react';
import { useState, useEffect } from 'react';

export function Hero() {
  const [greeting, setGreeting] = useState({ message: '', icon: Sun });

  useEffect(() => {
    const updateGreeting = () => {
      // Update greeting based on Dhaka time
      const dhakaTime = new Date();
      const hour = parseInt(new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Dhaka',
        hour: '2-digit',
        hour12: false,
      }).format(dhakaTime));

      if (hour >= 5 && hour < 12) {
        setGreeting({ message: 'Good Morning', icon: Sun });
      } else if (hour >= 12 && hour < 17) {
        setGreeting({ message: 'Good Afternoon', icon: CloudSun });
      } else if (hour >= 17 && hour < 21) {
        setGreeting({ message: 'Good Evening', icon: Sunset });
      } else {
        setGreeting({ message: 'Good Night', icon: Moon });
      }
    };

    updateGreeting();
    const interval = setInterval(updateGreeting, 60000); // Update every minute

    return () => clearInterval(interval);
  }, []);

  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const GreetingIcon = greeting.icon;

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0a0f] via-[#111827] to-[#1e293b] pt-16 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
        <div className="flex flex-col items-center justify-center text-center min-h-[80vh]">
          
          {/* Greeting Badge */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6"
          >
            <div className="inline-flex items-center bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-full px-5 py-2.5 backdrop-blur-sm">
              <GreetingIcon className="text-yellow-400 mr-2" size={20} />
              <span className="text-white">{greeting.message}!</span>
            </div>
          </motion.div>

          {/* Name */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white mb-4">
              Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Horaira</span>
            </h1>
          </motion.div>

          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-6"
          >
            <p className="text-lg sm:text-xl lg:text-2xl text-gray-300 leading-relaxed max-w-3xl">
              Junior Researcher in the field of AI & ML, Deep Learning, Data Science and Data Analyst
            </p>
          </motion.div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mb-8"
          >
            <p className="text-gray-400 leading-relaxed max-w-2xl text-lg">
              I create beautiful, AI & ML based Projects and Applications that help businesses grow and succeed in Technology in the digital world.
            </p>
          </motion.div>

          {/* Social Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex space-x-4 mb-12"
          >
            <a
              href="https://github.com/Horaira-s/my-first-step"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative p-4 rounded-lg bg-white/5 backdrop-blur-sm border border-white/10 hover:border-blue-500/50 transition-all text-white hover:bg-white/10 transform hover:scale-110"
            >
              <Github size={28} className="group-hover:text-blue-400 transition-colors" />
            </a>
            <a
              href="https://www.linkedin.com/in/abu-horaira-79774b2b2"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative p-4 rounded-lg bg-white/5 backdrop-blur-sm border border-white/10 hover:border-blue-500/50 transition-all text-white hover:bg-white/10 transform hover:scale-110"
            >
              <Linkedin size={28} className="group-hover:text-blue-400 transition-colors" />
            </a>
            <a
              href="mailto:sarder2205101514@diu.edu.bd"
              className="group relative p-4 rounded-lg bg-white/5 backdrop-blur-sm border border-white/10 hover:border-blue-500/50 transition-all text-white hover:bg-white/10 transform hover:scale-110"
            >
              <Mail size={28} className="group-hover:text-blue-400 transition-colors" />
            </a>
          </motion.div>

          {/* Scroll Down Button */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <button
              onClick={scrollToAbout}
              className="group flex flex-col items-center space-y-2 text-gray-400 hover:text-blue-400 transition-colors"
            >
              <span className="text-sm">Scroll to explore</span>
              <ArrowDown size={24} className="animate-bounce" />
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

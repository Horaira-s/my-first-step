import profileImage from 'figma:asset/2ac3162ab13bddd1ce627597d2a68841a1afdfbb.png';
import { motion } from 'motion/react';
import { useInView } from './hooks/useInView';

export function About() {
  const { ref, isInView } = useInView();

  return (
    <section id="about" className="py-20 bg-[#0f0f14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl text-center text-white mb-12">About Me</h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <p className="text-lg text-gray-300 mb-4">
                I'm a passionate about Programming. I already know about C, C++, Python, Basic SQL, Basic HTML, CSS & JavaScript, Cisco Network and the major part I will love to work ML, AI, Deep Learning, NLP. My journey in tech started with a curiosity about Programming Language and Networking Operation work in Windows, Mac & Linux system.
              </p>
              <p className="text-lg text-gray-300 mb-4">
                I specialize in modern web technologies including React, TypeScript, Node.js, and cloud platforms. I believe in writing clean, maintainable code and creating user experiences that are both beautiful and functional.
              </p>
              <p className="text-lg text-gray-300">
                When I'm not coding, you can find me exploring new technologies, contributing to open-source projects, or sharing my knowledge through tech blogs and mentoring.
              </p>
            </div>

            <div className="order-1 md:order-2">
              <div className="rounded-lg overflow-hidden shadow-2xl border border-white/10 bg-gradient-to-br from-blue-500/10 to-purple-500/10">
                <img
                  src={profileImage}
                  alt="Horaira - Professional Profile"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

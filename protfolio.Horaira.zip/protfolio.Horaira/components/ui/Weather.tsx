import { useState, useEffect } from 'react';
import { Cloud, CloudRain, Sun, CloudSnow, Wind, Droplets, Eye, Gauge, MapPin } from 'lucide-react';

interface WeatherData {
  temp: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  pressure: number;
  visibility: number;
  feelsLike: number;
  icon: string;
  city: string;
  country: string;
  countryCode: string;
}

interface LocationData {
  latitude: number;
  longitude: number;
}

export function Weather() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [locationError, setLocationError] = useState('');
  const [location, setLocation] = useState<LocationData | null>(null);

  // Get user's current location
  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          setLocationError('Location access denied. Showing default location (Dhaka).');
          // Default to Dhaka coordinates if location access is denied
          setLocation({
            latitude: 23.8103,
            longitude: 90.4125,
          });
        }
      );
    } else {
      setLocationError('Geolocation not supported. Showing default location (Dhaka).');
      // Default to Dhaka coordinates
      setLocation({
        latitude: 23.8103,
        longitude: 90.4125,
      });
    }
  }, []);

  // Fetch weather data based on location
  useEffect(() => {
    if (!location) return;

    const fetchWeather = async () => {
      try {
        // Using OpenWeatherMap API
        // Replace 'YOUR_API_KEY_HERE' with your actual API key from https://openweathermap.org/api
        const API_KEY = 'YOUR_API_KEY_HERE';
        
        // For demo purposes, if no API key is set, use mock data based on location
        if (API_KEY === 'YOUR_API_KEY_HERE') {
          // Mock data for demonstration
          setTimeout(() => {
            // Determine location name based on coordinates (rough estimation)
            const isDhaka = Math.abs(location.latitude - 23.8103) < 1 && Math.abs(location.longitude - 90.4125) < 1;
            
            setWeather({
              temp: isDhaka ? 28 : 22,
              condition: 'Partly Cloudy',
              humidity: 65,
              windSpeed: 12,
              pressure: 1012,
              visibility: 10,
              feelsLike: isDhaka ? 30 : 24,
              icon: 'partly-cloudy',
              city: isDhaka ? 'Dhaka' : 'Your Location',
              country: isDhaka ? 'Bangladesh' : 'Unknown',
              countryCode: isDhaka ? 'BD' : 'XX'
            });
            setLoading(false);
          }, 1000);
          return;
        }

        const response = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?lat=${location.latitude}&lon=${location.longitude}&appid=${API_KEY}&units=metric`
        );

        if (!response.ok) throw new Error('Weather data fetch failed');

        const data = await response.json();

        setWeather({
          temp: Math.round(data.main.temp),
          condition: data.weather[0].main,
          humidity: data.main.humidity,
          windSpeed: Math.round(data.wind.speed * 3.6), // Convert m/s to km/h
          pressure: data.main.pressure,
          visibility: Math.round(data.visibility / 1000), // Convert to km
          feelsLike: Math.round(data.main.feels_like),
          icon: data.weather[0].main.toLowerCase(),
          city: data.name,
          country: data.sys.country,
          countryCode: data.sys.country
        });
        setLoading(false);
      } catch (err) {
        console.error('Error fetching weather:', err);
        setError(true);
        setLoading(false);
      }
    };

    fetchWeather();
    // Refresh weather every 10 minutes
    const interval = setInterval(fetchWeather, 600000);

    return () => clearInterval(interval);
  }, [location]);

  const getWeatherIcon = (condition: string) => {
    const iconCondition = condition?.toLowerCase() || '';
    if (iconCondition.includes('clear') || iconCondition.includes('sun')) {
      return <Sun className="text-yellow-400" size={32} />;
    } else if (iconCondition.includes('rain') || iconCondition.includes('drizzle')) {
      return <CloudRain className="text-blue-400" size={32} />;
    } else if (iconCondition.includes('snow')) {
      return <CloudSnow className="text-blue-200" size={32} />;
    } else if (iconCondition.includes('cloud') || iconCondition.includes('partly')) {
      return <Cloud className="text-gray-400" size={32} />;
    } else {
      return <Sun className="text-yellow-400" size={32} />;
    }
  };

  const getCountryFlag = (countryCode: string) => {
    if (countryCode === 'BD') return '🇧🇩';
    if (countryCode === 'US') return '🇺🇸';
    if (countryCode === 'GB') return '🇬🇧';
    if (countryCode === 'IN') return '🇮🇳';
    if (countryCode === 'PK') return '🇵🇰';
    if (countryCode === 'AU') return '🇦🇺';
    if (countryCode === 'CA') return '🇨🇦';
    if (countryCode === 'DE') return '🇩🇪';
    if (countryCode === 'FR') return '🇫🇷';
    if (countryCode === 'JP') return '🇯🇵';
    if (countryCode === 'CN') return '🇨🇳';
    if (countryCode === 'BR') return '🇧🇷';
    if (countryCode === 'ZA') return '🇿🇦';
    if (countryCode === 'IT') return '🇮🇹';
    if (countryCode === 'ES') return '🇪🇸';
    if (countryCode === 'MX') return '🇲🇽';
    if (countryCode === 'RU') return '🇷🇺';
    if (countryCode === 'KR') return '🇰🇷';
    if (countryCode === 'ID') return '🇮🇩';
    if (countryCode === 'TR') return '🇹🇷';
    if (countryCode === 'SA') return '🇸🇦';
    if (countryCode === 'AE') return '🇦🇪';
    if (countryCode === 'TH') return '🇹🇭';
    if (countryCode === 'PH') return '🇵🇭';
    if (countryCode === 'MY') return '🇲🇾';
    if (countryCode === 'SG') return '🇸🇬';
    if (countryCode === 'NZ') return '🇳🇿';
    if (countryCode === 'AR') return '🇦🇷';
    if (countryCode === 'CL') return '🇨🇱';
    if (countryCode === 'EG') return '🇪🇬';
    if (countryCode === 'NG') return '🇳🇬';
    if (countryCode === 'KE') return '🇰🇪';
    return '🌍'; // Default world emoji
  };

  if (loading) {
    return (
      <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:border-blue-500/50 transition-all">
        <div className="animate-pulse">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="h-6 w-32 bg-white/10 rounded mb-2"></div>
              <div className="h-4 w-24 bg-white/10 rounded"></div>
            </div>
            <div className="h-8 w-8 bg-white/10 rounded-full"></div>
          </div>
          <div className="h-12 w-24 bg-white/10 rounded mb-4"></div>
          <div className="space-y-2">
            <div className="h-4 w-full bg-white/10 rounded"></div>
            <div className="h-4 w-full bg-white/10 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !weather) {
    return (
      <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
        <p className="text-gray-400 text-center">Unable to load weather data</p>
        {locationError && (
          <p className="text-yellow-400 text-xs text-center mt-2">{locationError}</p>
        )}
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6 hover:border-blue-500/50 transition-all">
      {/* Location and Main Weather */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-white text-xl flex items-center">
            <span className="mr-2">{getCountryFlag(weather.countryCode)}</span>
            {weather.city}
          </h3>
          <p className="text-gray-400 text-sm flex items-center">
            <MapPin size={12} className="mr-1" />
            {weather.country}
          </p>
        </div>
        {getWeatherIcon(weather.condition)}
      </div>

      {/* Temperature */}
      <div className="mb-4">
        <div className="flex items-baseline">
          <span className="text-5xl text-white">{weather.temp}</span>
          <span className="text-2xl text-gray-400 ml-1">°C</span>
        </div>
        <p className="text-blue-400 text-lg">{weather.condition}</p>
        <p className="text-gray-400 text-sm">Feels like {weather.feelsLike}°C</p>
      </div>

      {/* Weather Details Grid */}
      <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-white/10">
        <div className="flex items-center">
          <Droplets className="text-blue-400 mr-2" size={16} />
          <div>
            <p className="text-gray-400 text-xs">Humidity</p>
            <p className="text-white text-sm">{weather.humidity}%</p>
          </div>
        </div>
        
        <div className="flex items-center">
          <Wind className="text-gray-400 mr-2" size={16} />
          <div>
            <p className="text-gray-400 text-xs">Wind</p>
            <p className="text-white text-sm">{weather.windSpeed} km/h</p>
          </div>
        </div>
        
        <div className="flex items-center">
          <Gauge className="text-purple-400 mr-2" size={16} />
          <div>
            <p className="text-gray-400 text-xs">Pressure</p>
            <p className="text-white text-sm">{weather.pressure} hPa</p>
          </div>
        </div>
        
        <div className="flex items-center">
          <Eye className="text-green-400 mr-2" size={16} />
          <div>
            <p className="text-gray-400 text-xs">Visibility</p>
            <p className="text-white text-sm">{weather.visibility} km</p>
          </div>
        </div>
      </div>

      {/* Location Notice */}
      {locationError && (
        <div className="mt-4 pt-4 border-t border-white/10">
          <p className="text-xs text-yellow-400/70 text-center">
            ℹ️ {locationError}
          </p>
        </div>
      )}

      {/* API Notice */}
      {!locationError && weather.city === 'Your Location' && (
        <div className="mt-4 pt-4 border-t border-white/10">
          <p className="text-xs text-yellow-400/70 text-center">
            📝 Using demo data. Add your API key to get live weather.
          </p>
        </div>
      )}
    </div>
  );
}

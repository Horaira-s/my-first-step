import { useState, useEffect } from 'react';
import { Cloud, CloudRain, Sun, CloudSnow, Wind, Clock, Calendar, PartyPopper, Droplets, Thermometer } from 'lucide-react';
import { motion } from 'motion/react';

interface WeatherData {
  temp: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  city: string;
  countryCode: string;
}

interface TimeZoneData {
  city: string;
  timezone: string;
  flag: string;
}

interface Holiday {
  name: string;
  date: string;
  flag: string;
}

const timeZones: TimeZoneData[] = [
  { city: 'Dhaka', timezone: 'Asia/Dhaka', flag: '🇧🇩' },
  { city: 'New York', timezone: 'America/New_York', flag: '🇺🇸' },
  { city: 'London', timezone: 'Europe/London', flag: '🇬🇧' },
];

const holidays: Holiday[] = [
  { name: 'International Mother Language Day', date: '02-21', flag: '🇧🇩' },
  { name: 'Independence Day (Bangladesh)', date: '03-26', flag: '🇧🇩' },
  { name: 'Bengali New Year', date: '04-14', flag: '🇧🇩' },
  { name: 'Victory Day (Bangladesh)', date: '12-16', flag: '🇧🇩' },
  { name: "New Year's Day", date: '01-01', flag: '🌍' },
  { name: "Valentine's Day", date: '02-14', flag: '❤️' },
  { name: 'Earth Day', date: '04-22', flag: '🌍' },
  { name: 'Halloween', date: '10-31', flag: '🎃' },
  { name: 'Christmas Day', date: '12-25', flag: '🎄' },
];

export function CompactInfoBar() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [currentTimes, setCurrentTimes] = useState<Map<string, Date>>(new Map());
  const [upcomingHolidays, setUpcomingHolidays] = useState<any[]>([]);

  // Fetch weather
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(resolve, reject);
          } else {
            reject(new Error('Geolocation not supported'));
          }
        });

        const { latitude, longitude } = position.coords;
        
        // Mock weather data (replace with API call if you have a key)
        setTimeout(() => {
          const isDhaka = Math.abs(latitude - 23.8103) < 1 && Math.abs(longitude - 90.4125) < 1;
          setWeather({
            temp: isDhaka ? 28 : 22,
            condition: 'Partly Cloudy',
            humidity: 65,
            windSpeed: 12,
            city: isDhaka ? 'Dhaka' : 'Your Location',
            countryCode: isDhaka ? 'BD' : 'XX'
          });
        }, 500);
      } catch (error) {
        // Default to Dhaka
        setWeather({
          temp: 28,
          condition: 'Partly Cloudy',
          humidity: 65,
          windSpeed: 12,
          city: 'Dhaka',
          countryCode: 'BD'
        });
      }
    };

    fetchWeather();
  }, []);

  // Update world clocks
  useEffect(() => {
    const updateTimes = () => {
      const newTimes = new Map<string, Date>();
      timeZones.forEach(tz => {
        newTimes.set(tz.timezone, new Date());
      });
      setCurrentTimes(newTimes);
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  // Calculate upcoming holidays
  useEffect(() => {
    const today = new Date();
    const currentYear = today.getFullYear();
    
    const holidaysWithDates = holidays.map(holiday => {
      const [month, day] = holiday.date.split('-').map(Number);
      const holidayDate = new Date(currentYear, month - 1, day);
      
      if (holidayDate < today) {
        holidayDate.setFullYear(currentYear + 1);
      }
      
      const daysUntil = Math.ceil((holidayDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      return { ...holiday, holidayDate, daysUntil };
    });

    setUpcomingHolidays(holidaysWithDates.sort((a, b) => a.daysUntil - b.daysUntil).slice(0, 3));
  }, []);

  const getWeatherIcon = (condition: string) => {
    const iconCondition = condition?.toLowerCase() || '';
    if (iconCondition.includes('clear') || iconCondition.includes('sun')) {
      return <Sun className="text-yellow-400" size={28} />;
    } else if (iconCondition.includes('rain') || iconCondition.includes('drizzle')) {
      return <CloudRain className="text-blue-400" size={28} />;
    } else if (iconCondition.includes('snow')) {
      return <CloudSnow className="text-blue-200" size={28} />;
    } else if (iconCondition.includes('cloud') || iconCondition.includes('partly')) {
      return <Cloud className="text-gray-400" size={28} />;
    } else {
      return <Sun className="text-yellow-400" size={28} />;
    }
  };

  const formatTime = (date: Date, timezone: string) => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).format(date);
  };

  const getCountryFlag = (code: string) => {
    if (code === 'BD') return '🇧🇩';
    return '🌍';
  };

  return (
    <div className="w-full bg-gradient-to-br from-[#0a0a0f] via-[#0f1729] to-[#1a1f35] py-8 border-b border-blue-500/20 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-6"
        >
          <h2 className="text-2xl text-white mb-2">
            Live <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Information</span> Dashboard
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* LEFT - Weather */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-md border-2 border-blue-500/40 rounded-2xl p-6 hover:border-blue-400/60 hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Thermometer className="text-blue-400 mr-2" size={20} />
                <h3 className="text-white">Current Weather</h3>
              </div>
              {weather && getWeatherIcon(weather.condition)}
            </div>
            
            {weather ? (
              <div>
                <div className="flex items-baseline mb-3">
                  <span className="text-5xl text-white">{weather.temp}</span>
                  <span className="text-2xl text-blue-300 ml-2">°C</span>
                </div>
                <p className="text-blue-400 text-lg mb-2">{weather.condition}</p>
                
                <div className="flex items-center text-sm text-gray-300 mb-4">
                  <span className="text-xl mr-2">{getCountryFlag(weather.countryCode)}</span>
                  <span>{weather.city}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/20">
                  <div className="bg-white/10 rounded-lg p-3">
                    <div className="flex items-center justify-center mb-1">
                      <Wind className="text-blue-400" size={16} />
                    </div>
                    <p className="text-white text-center">{weather.windSpeed} km/h</p>
                    <p className="text-gray-400 text-xs text-center">Wind Speed</p>
                  </div>
                  <div className="bg-white/10 rounded-lg p-3">
                    <div className="flex items-center justify-center mb-1">
                      <Droplets className="text-blue-400" size={16} />
                    </div>
                    <p className="text-white text-center">{weather.humidity}%</p>
                    <p className="text-gray-400 text-xs text-center">Humidity</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="animate-pulse">
                <div className="h-12 w-24 bg-white/20 rounded mb-3"></div>
                <div className="h-6 w-32 bg-white/20 rounded mb-4"></div>
                <div className="h-4 w-28 bg-white/20 rounded"></div>
              </div>
            )}
          </motion.div>

          {/* MIDDLE - World Clock */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md border-2 border-white/30 rounded-2xl p-6 hover:border-blue-400/60 hover:shadow-2xl hover:shadow-blue-500/10 transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center mb-5">
              <div className="bg-blue-500/20 p-2 rounded-lg mr-3">
                <Clock className="text-blue-400" size={20} />
              </div>
              <h3 className="text-white">World Clock</h3>
            </div>
            
            <div className="space-y-4">
              {timeZones.map((tz) => {
                const currentTime = currentTimes.get(tz.timezone);
                return (
                  <div 
                    key={tz.timezone} 
                    className="bg-white/10 rounded-lg p-3 hover:bg-white/15 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="text-2xl mr-3">{tz.flag}</span>
                        <span className="text-gray-300">{tz.city}</span>
                      </div>
                      {currentTime && (
                        <span className="text-blue-400">{formatTime(currentTime, tz.timezone)}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* RIGHT - Upcoming Holidays */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-gradient-to-br from-pink-500/20 to-purple-500/20 backdrop-blur-md border-2 border-pink-500/40 rounded-2xl p-6 hover:border-pink-400/60 hover:shadow-2xl hover:shadow-pink-500/20 transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center mb-5">
              <div className="bg-pink-500/20 p-2 rounded-lg mr-3">
                <PartyPopper className="text-pink-400" size={20} />
              </div>
              <h3 className="text-white">Upcoming Holidays</h3>
            </div>
            
            <div className="space-y-3">
              {upcomingHolidays.map((holiday, index) => (
                <div 
                  key={index} 
                  className="bg-white/10 rounded-lg p-3 hover:bg-white/15 transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start flex-1">
                      <span className="text-xl mr-2">{holiday.flag}</span>
                      <div>
                        <p className="text-white text-sm">{holiday.name}</p>
                        <p className="text-gray-400 text-xs mt-1">
                          {holiday.holidayDate.toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs text-pink-400 bg-pink-500/30 px-2 py-1 rounded-full whitespace-nowrap ml-2">
                      {holiday.daysUntil === 0 ? '🎉 Today!' : holiday.daysUntil === 1 ? '📅 Tomorrow' : `📆 ${holiday.daysUntil} days`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
}

import { Clock } from 'lucide-react';
import { useState, useEffect } from 'react';

interface TimeZoneData {
  city: string;
  timezone: string;
  flag: string;
}

const timeZones: TimeZoneData[] = [
  { city: 'New York', timezone: 'America/New_York', flag: '🇺🇸' },
  { city: 'London', timezone: 'Europe/London', flag: '🇬🇧' },
  { city: 'Tokyo', timezone: 'Asia/Tokyo', flag: '🇯🇵' },
  { city: 'Dubai', timezone: 'Asia/Dubai', flag: '🇦🇪' },
  { city: 'Sydney', timezone: 'Australia/Sydney', flag: '🇦🇺' },
  { city: 'Dhaka', timezone: 'Asia/Dhaka', flag: '🇧🇩' },
];

export function WorldClock() {
  const [currentTimes, setCurrentTimes] = useState<Map<string, Date>>(new Map());

  useEffect(() => {
    const updateTimes = () => {
      const newTimes = new Map<string, Date>();
      timeZones.forEach(tz => {
        newTimes.set(tz.timezone, new Date());
      });
      setCurrentTimes(newTimes);
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (date: Date, timezone: string) => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }).format(date);
  };

  const formatDate = (date: Date, timezone: string) => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  };

  return (
    <div className="w-full bg-[#0f0f14] border-y border-white/10 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center mb-6">
          <Clock className="text-blue-500 mr-2" size={24} />
          <h3 className="text-2xl text-white">World Clock</h3>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {timeZones.map((tz) => {
            const currentTime = currentTimes.get(tz.timezone);
            return (
              <div
                key={tz.timezone}
                className="bg-[#18181b] border border-white/10 rounded-lg p-4 hover:border-blue-500/50 transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl">{tz.flag}</span>
                  <span className="text-xs text-gray-400">{tz.timezone.split('/')[1]}</span>
                </div>
                <h4 className="text-white mb-1">{tz.city}</h4>
                {currentTime && (
                  <>
                    <p className="text-blue-400 text-lg">
                      {formatTime(currentTime, tz.timezone)}
                    </p>
                    <p className="text-gray-400 text-xs mt-1">
                      {formatDate(currentTime, tz.timezone)}
                    </p>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

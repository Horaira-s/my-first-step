# Database Schema for Get In Touch Contact Form

## Table: contact_submissions

This table stores all contact form submissions from your portfolio website.

### Schema Structure

| Column Name | Data Type | Constraints | Description |
|-------------|-----------|-------------|-------------|
| id | UUID | PRIMARY KEY, DEFAULT uuid_generate_v4() | Unique identifier for each submission |
| name | TEXT | NOT NULL | Visitor's name |
| email | TEXT | NOT NULL | Visitor's email address |
| message | TEXT | NOT NULL | Message content from visitor |
| created_at | TIMESTAMP | DEFAULT NOW() | Timestamp when submission was created |
| read | BOOLEAN | DEFAULT FALSE | Mark if you've read the message |
| replied | BOOLEAN | DEFAULT FALSE | Mark if you've replied to the message |

### SQL Create Table Statement

```sql
CREATE TABLE contact_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  read BOOLEAN DEFAULT FALSE,
  replied BOOLEAN DEFAULT FALSE
);
```

### Indexes for Performance

```sql
-- Index on created_at for sorting by date
CREATE INDEX idx_contact_submissions_created_at ON contact_submissions(created_at DESC);

-- Index on read status for filtering unread messages
CREATE INDEX idx_contact_submissions_read ON contact_submissions(read);

-- Index on email for searching by sender
CREATE INDEX idx_contact_submissions_email ON contact_submissions(email);
```

### Row Level Security (RLS) Policies

```sql
-- Enable RLS
ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (submit contact form)
CREATE POLICY "Anyone can submit contact form"
  ON contact_submissions
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Only authenticated users (you) can view submissions
CREATE POLICY "Only authenticated users can view submissions"
  ON contact_submissions
  FOR SELECT
  TO authenticated
  USING (true);

-- Only authenticated users (you) can update submissions
CREATE POLICY "Only authenticated users can update submissions"
  ON contact_submissions
  FOR UPDATE
  TO authenticated
  USING (true);
```

## How to Set This Up in Supabase

### Option 1: Using Supabase Dashboard (SQL Editor)

1. Log in to your Supabase project dashboard
2. Navigate to **SQL Editor** in the left sidebar
3. Click **"New Query"**
4. Copy and paste the SQL statements above
5. Click **"Run"** to execute
6. Go to **Table Editor** to view your new table

### Option 2: Using Supabase Dashboard (Table Editor)

1. Log in to your Supabase project dashboard
2. Navigate to **Table Editor** in the left sidebar
3. Click **"New Table"**
4. Set table name: `contact_submissions`
5. Add columns as specified in the schema above
6. Enable RLS and add policies as needed

### Viewing Your Schema

Once created, you can view your database schema in several ways:

1. **Table Editor**: Visual representation of your tables and columns
2. **Database** → **Schema Visualizer**: See relationships between tables
3. **SQL Editor**: Run `\d contact_submissions` to see table structure
4. **API Docs**: Auto-generated API documentation based on your schema

## Sample Data Structure

Here's what a typical record would look like:

```json
{
  "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "name": "John Doe",
  "email": "john.doe@example.com",
  "message": "Hi Horaira, I'd like to discuss a project opportunity with you.",
  "created_at": "2025-11-22T10:30:00.000Z",
  "read": false,
  "replied": false
}
```

## Future Enhancements

You could extend this schema with:

- **subject** (TEXT): Add a subject field to the form
- **phone** (TEXT): Optional phone number field
- **company** (TEXT): Company name if relevant
- **project_type** (TEXT): Type of inquiry (job, project, collaboration, etc.)
- **priority** (TEXT): Low, medium, high priority
- **notes** (TEXT): Your internal notes about the submission
- **ip_address** (TEXT): Track sender's IP for spam prevention
- **user_agent** (TEXT): Browser information
- **spam_score** (INTEGER): If you implement spam detection

## Integration with Your Contact Form

Once the database is set up, you would update your `/components/Contact.tsx` to use Supabase:

```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  'YOUR_SUPABASE_URL',
  'YOUR_SUPABASE_ANON_KEY'
);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  
  const { data, error } = await supabase
    .from('contact_submissions')
    .insert([
      {
        name: formData.name,
        email: formData.email,
        message: formData.message,
      }
    ]);
  
  if (error) {
    console.error('Error submitting form:', error);
    // Show error message to user
  } else {
    console.log('Form submitted successfully:', data);
    setIsSubmitted(true);
    // Reset form...
  }
};
```

---

**Note**: This is a reference document showing the proposed database schema. To actually implement this, you would need to connect to Supabase and create the table using the SQL statements provided above.
